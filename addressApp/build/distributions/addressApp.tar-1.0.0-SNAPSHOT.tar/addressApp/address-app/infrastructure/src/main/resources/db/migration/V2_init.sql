create table birthdate (id UUID PRIMARY KEY , day NUMERIC, month NUMERIC, year NUMERIC);
