insert into birthdate(id, day, month, year) VALUES (uuid('fe6ae8fc-d4f9-4448-a9e1-6a5de4284b92'), 2, 1, 2000);
