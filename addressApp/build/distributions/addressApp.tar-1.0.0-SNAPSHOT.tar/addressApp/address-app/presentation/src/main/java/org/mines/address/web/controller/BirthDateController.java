package org.mines.address.web.controller;

import org.mines.address.api.controller.BirthdateApi;
import org.mines.address.api.model.Birthdate;
import org.mines.address.api.model.Town;
import org.mines.civilstate.domain.model.BirthDate;
import org.mines.civilstate.port.driving.BirthDateUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping
public class BirthDateController implements BirthdateApi {
    private BirthDateUseCase birthDateUseCase;

    @Autowired
    public BirthDateController(BirthDateUseCase birthDateUseCase) {
        this.birthDateUseCase = birthDateUseCase;
    }

    public ResponseEntity<Birthdate> createBirthdate(Birthdate birthdate) {
        org.mines.civilstate.domain.model.BirthDate saved = birthDateUseCase.save(this.map(birthdate));

        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path(
                "/{id}").buildAndExpand(saved.id()).toUri();

        return ResponseEntity.created(uri).body(map(saved));
    }

    public ResponseEntity<String> deleteBithDate(String id) {
        birthDateUseCase.remove(UUID.fromString(id));

        return ResponseEntity.ok(id);
    }

    public ResponseEntity<Birthdate> getBirthDate(String id) {
        UUID uuid = UUID.fromString(id);

        return birthDateUseCase.get(uuid)
                .map(this::map)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    public ResponseEntity<List<Birthdate>> listBirthDates() {
        return ResponseEntity.ok(birthDateUseCase.list().stream().map(this::map).collect(Collectors.toList()));
    }

    public ResponseEntity<Birthdate> updateBirthdate(Birthdate birthdate) {
        org.mines.civilstate.domain.model.BirthDate modelBirthDate = this.map(birthdate);

        if (birthDateUseCase.get(UUID.fromString(birthdate.getId())).isPresent()) {
            return ResponseEntity.ok(this.map(birthDateUseCase.save(modelBirthDate)));
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    private BirthDate map(Birthdate birthdate) {
        return new BirthDate.BirthDateBuilder()
                .withId(birthdate.getId() == null ? null : UUID.fromString(birthdate.getId()))
                .withDay(birthdate.getDay())
                .withMonth(birthdate.getMonth())
                .withYear(birthdate.getYear())
                .build();
    }

    private Birthdate map(org.mines.civilstate.domain.model.BirthDate birthdate) {
        Birthdate apiBirthdate = new Birthdate();
        apiBirthdate.setId(apiBirthdate.getId());
        apiBirthdate.setDay(birthdate.day());
        apiBirthdate.setMonth(birthdate.month());
        apiBirthdate.setYear(birthdate.year());

        return apiBirthdate;
    }



}
